<template>
  <div>
    <p><label>Ingrese el nombre del producto</label></p>
    <input type="text" placeholder="Nombre del producto" :value="$store.state.nombre" />
    <button class="btn btn-primary" @click="buscarProducto">Buscar</button>
    <div class="card-actions">
      <div id="resultado">
      </div>
    </div>
  </div>
</template>

<script>
//import {productos} from './store/modules/productos'

export default {
  name: 'Busquedas',
  //props: {
  //  producto: { type: Object, required: true }
  //}
  mutations: {
    buscar(state, nombreProducto){
      state.todosLosProductos.filter(nombreProducto)
    }
  },
  actions: {
    buscarProducto(context, nombre) {
      context.commit('buscar', nombre)
    }
  }
}
</script>

<style></style>
